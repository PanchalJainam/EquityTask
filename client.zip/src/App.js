// import logo from "./logo.svg";
import "./App.css";
// import Navbar from "./components/Navbar/Navbar";
import Router from "./Router/Router";

function App() {
  return <Router />;
}

export default App;
